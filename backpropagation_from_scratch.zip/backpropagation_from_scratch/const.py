import numpy as np

# Radnom generator for reproducibility
rng = np.random.default_rng(42)

# Neural Network 

INPUT_SIZE = 8
HIDDEN_SIZE = 3
OUTPUT_SIZE = 8

